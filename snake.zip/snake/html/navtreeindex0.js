var NAVTREEINDEX0 =
{
"_snake_8cs.html":[1,0,0],
"_snake_8cs_source.html":[1,0,0],
"annotated.html":[0,0],
"class_snake.html":[0,0,0],
"class_snake.html#a3f03258f4a3a1f9d19bb3b9f275d2520":[0,0,0,3],
"class_snake.html#a70588fe9278af1074c6c8759b11a383b":[0,0,0,1],
"class_snake.html#ab6f41970c6c468c71c42824261649b4b":[0,0,0,0],
"class_snake.html#abb4579eda9cb9000b93caf990189934d":[0,0,0,2],
"classes.html":[0,1],
"files.html":[1,0],
"functions.html":[0,2,0],
"functions_func.html":[0,2,1],
"functions_vars.html":[0,2,2],
"index.html":[],
"pages.html":[]
};
