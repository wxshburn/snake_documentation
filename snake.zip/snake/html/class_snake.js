var class_snake =
[
    [ "Main", "class_snake.html#ab6f41970c6c468c71c42824261649b4b", null ],
    [ "Delay", "class_snake.html#a70588fe9278af1074c6c8759b11a383b", null ],
    [ "H", "class_snake.html#abb4579eda9cb9000b93caf990189934d", null ],
    [ "W", "class_snake.html#a3f03258f4a3a1f9d19bb3b9f275d2520", null ]
];