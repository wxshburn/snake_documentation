var annotated_dup =
[
    [ "Snake", "class_snake.html", "class_snake" ]
];